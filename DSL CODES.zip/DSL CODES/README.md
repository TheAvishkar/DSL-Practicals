Codes for SPPU 2019 Fundamentals of Data Structure Practicals, 
MicroProject for Fundamentals of Data Structure Included (Python)
